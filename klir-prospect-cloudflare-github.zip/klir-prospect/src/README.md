# Klir Prospect (Perchance MVP)

Plateforme Prospect Intelligence + AI Sales Automation — flux critique : SEARCH → QUALIFY → SELECT → CRM → AI OUTREACH.

## Fichiers
- `main.pjs` : imports `ai-text-plugin` (Klir AI / messages), `kv-plugin` (réservé).
- `index.html` : shell + CSS.
- `src/data.js` : secteurs, villes, noms procéduraux.
- `src/engine.js` : parseQuery, genProspects, dedup (fingerprint), scores Q/R, analyse IA.
- `src/store.js` : persistance localStorage `klir_prospect_v1` (legacy) + `klir_prospect_v2_<email>` par compte + `klir_accounts_v1` (email→hash) + sauvegarde kv-plugin en arrière-plan. Recherches/CRM liés à l'e-mail.
- `src/webintel.js` : WEBSITE & DOMAIN INTELLIGENCE (statuts site/domaine séparés, DNS via dns.google, HTTP via superFetch, RDAP .com/.ca, cache 24h, bulk ≤100/batch). Échec → ⚪ UNKNOWN, jamais « disponible » sans preuve RDAP/registre.
- `src/opportunity.js` : OPPORTUNITY INTELLIGENCE ENGINE v1 (ICP 0-100, signaux typés avec preuve/source/confiance/poids + plafonds par groupe, 6 besoins, matching 6 services Klirline, score 30/25/25/20, priorités, gates DQ<40 et confiance, versioning). Configurable dans Admin.
- `src/app.js` : SPA hash-router (landing, login/register/forgot, onboarding, dashboard, prospecting/new/searches/results, prospects, crm, campaigns, ai, analytics, admin, settings).

## État (PROD V1 — klirprospect.klirline.ca)
Scores : Data Quality / Relevance / Confidence / Intent / Opportunity (cliquables → détail du calcul). Connecteur live Sirene (recherche-entreprises.api.gouv.fr, sans clé, recherches France). Déduplication multi-clés (domaine/tél/email/nom/adresse) + Exact/Possible + fusion. Radar configurable (signaux, fréquence) + stats de scan. Mode DEMO/LIVE. Funnel analytics + pipeline $. Export autonome : voir le zip du site (index.html + src/).
Menu groupé (Prospecting / Ideal Customer / CRM / Klir AI / Outreach / Analytics / Settings + Outils). Dashboard : KPIs Prospects/Qualifiés/Opportunités/Actions, top opportunités, carte ICP + CTA, Copilot inline. CRM en 5 vues (Companies/Contacts/Leads/Deals/Activities), deals créés depuis les leads (€, Won cumulé), contacts publics + ajout manuel. Copilot et Messages en pages dédiées. Parcours ICP → Recherche → Qualification → Radar → CRM → Copilot → Outreach vérifié bout en bout.
Fait : + ICP Builder (défaut recherche/Radar/lists + fit /100), Radar opportunités (nouveaux/changements/signaux → analyse → action), Smart Lists (5 presets + personnalisées), Copilot (« que faire ensuite ? » avec actions), waterfall enrichment avec provenance, lead scoring réglable, import CSV → normalisation/déduplication, monitoring (watchlist + scans), intégrations Gmail/Outlook/HubSpot/Pipedrive (à configurer), API locale + clé + console + webhooks, crédits 🪙 avec coûts et recharge.
Non-fait (backend requis) : sources réelles, multi-tenant serveur, envois réels, Stripe, tests auto — voir `src/MIGRATION.md`.

## Reprendre
Ordre : V1.4 Klir AI tools sécurisés → V1.5 outreach avec revue/approbation → V1.6 analytics/billing. Données test : localStorage, `test@klirline.com`.
