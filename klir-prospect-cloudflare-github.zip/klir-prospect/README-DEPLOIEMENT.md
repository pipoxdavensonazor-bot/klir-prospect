# Klir Prospect — Déploiement GitHub + Cloudflare (FR)

## Contenu du dossier
- `index.html` : site statique autonome (aucun build requis).
- `src/*.js` : app (data, engine, store, webintel, opportunity, sources, app).
- Standalone : sur Perchance, l'IA utilise ai-text-plugin / superFetch / kv.
  Hors Perchance (`window.root` vide) l'app bascule en fallback : IA -> heuristiques locales, HTTP -> fetch natif, sauvegarde -> localStorage. Aucune erreur.

## 1. GitHub
```bash
cd export-klir-prospect
git init
git add .
git commit -m "Klir Prospect static export"
git branch -M main
git remote add origin https://github.com/VOTRE-COMPTE/klir-prospect.git
git push -u origin main
```

## 2. Cloudflare Pages (recommandé, gratuit)
1. https://dash.cloudflare.com -> Pages -> Create -> Connect to Git -> choisir `klir-prospect`.
2. Build : Framework preset = None, Build command = (vide), Output directory = `/` (racine, car index.html est à la racine).
3. Deploy. URL : https://klir-prospect.pages.dev puis domaine custom klirprospect.klirline.ca via Custom domains.

Alternative upload direct : Pages -> Create -> Upload assets -> glisser le dossier ou le zip.

## 3. Cloudflare Worker (optionnel, si besoin de proxy HTTP/DNS/RDAP anti-CORS)
Le fetch natif suffit pour la plupart des API avec CORS ouvert (Sirene, dns.google, RDAP).
Si une API bloque le navigateur, créez un Worker proxy : voir wrangler.toml (optionnel, non requis pour déployer).

## Notes
- Données : localStorage par compte (clé klir_prospect_v2_<email>), test : test@klirline.com.
- HTTPS requis (Cloudflare le fournit par défaut).
