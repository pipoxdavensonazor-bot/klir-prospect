# Klir Prospect — Déploiement GitHub + Cloudflare (FR)

## Contenu du dossier
- `index.html` : site statique autonome (aucun build requis).
- `src/*.js` : app (data, engine, store, webintel, opportunity, sources, webai, projects, team, recovery, nuage, app).
- Standalone : sur Perchance, l'IA utilise ai-text-plugin / superFetch / kv.
  Hors Perchance (`window.root` vide) l'app bascule en fallback : IA -> heuristiques locales, HTTP -> fetch natif, sauvegarde -> localStorage. Aucune erreur.

## 1. GitHub
```bash
cd export-klir-prospect
git init
git add .
git commit -m "Klir Prospect static export"
git branch -M main
git remote add origin https://github.com/VOTRE-COMPTE/klir-prospect.git
git push -u origin main
```

## 2. Cloudflare Pages (recommandé, gratuit)
1. https://dash.cloudflare.com -> Pages -> Create -> Connect to Git -> choisir `klir-prospect`.
2. Build : Framework preset = None, Build command = (vide), Output directory = `/` (racine, car index.html est à la racine).
3. Deploy. URL : https://klir-prospect.pages.dev puis domaine custom klirprospect.klirline.ca via Custom domains.

Alternative upload direct : Pages -> Create -> Upload assets -> glisser le dossier ou le zip.

## 3. Cloudflare Worker (optionnel, si besoin de proxy HTTP/DNS/RDAP anti-CORS)
Le fetch natif suffit pour la plupart des API avec CORS ouvert (Sirene, dns.google, RDAP).
Si une API bloque le navigateur, créez un Worker proxy : voir wrangler.toml (optionnel, non requis pour déployer).


## 4. Authentification Cloudflare Access (recommandé, gratuit jusqu'à 50 utilisateurs)
Protège l'ACCÈS à l'URL : sans le code reçu par e-mail, personne ne peut ouvrir l'app. Aucun changement de code requis.
1. https://dash.cloudflare.com -> (menu) Zero Trust -> premier passage : choisissez un nom d'équipe (ex. `klirline`), restez sur le plan gratuit.
2. Zero Trust -> Settings -> Authentication -> Login methods -> Add new -> **One-time PIN** (code à usage unique par e-mail).
3. Zero Trust -> Access -> Applications -> Add an application -> **Self-hosted**.
4. Name = `Klir Prospect`, Session Duration = 24h. Subdomain : laissez vide si vous protégez un domaine custom (ex. `klirprospect.klirline.ca` -> Domain = ce domaine) ; pour le domaine pages.dev, utilisez le chemin d'application correspondant.
5. Policy : Name = `Moi`, Action = **Allow**, règle Include -> **Emails** -> ajoutez votre e-mail (+ ceux de l'équipe). Tout le reste est bloqué par défaut.
6. Testez en navigation privée : l'URL demande votre e-mail, vous recevez un PIN, puis l'app s'ouvre.
Notes : révoquez un équipier en retirant son e-mail de la policy. Cela verrouille qui OUVRE l'app ; les données restent en plus chiffrées localement (comptes + fichier de secours). Sur Perchance, le Compte Klir garde ses propres mots de passe — indépendant d'Access.

## Notes
- Données : localStorage par compte (clé klir_prospect_v2_<email>), test : test@klirline.com.
- HTTPS requis (Cloudflare le fournit par défaut).
