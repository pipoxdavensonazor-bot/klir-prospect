var RC_BTAG = "klir-secours";
function rcB64e(buf){
  var u = new Uint8Array(buf), s = "";
  for (var i = 0; i < u.length; i += 8192) s += String.fromCharCode.apply(null, u.subarray(i, i + 8192));
  return btoa(s);
}
function rcB64d(b){
  var s = atob(b), u = new Uint8Array(s.length);
  for (var i = 0; i < s.length; i++) u[i] = s.charCodeAt(i);
  return u;
}
async function rcKey(pass, salt){
  var km = await window.crypto.subtle.importKey("raw", new TextEncoder().encode(pass), "PBKDF2", false, ["deriveKey"]);
  return window.crypto.subtle.deriveKey({ name: "PBKDF2", salt: salt, iterations: 200000, hash: "SHA-256" }, km, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}
function rcCollect(){
  var data = { accounts: null, buckets: {}, directory: null };
  try { data.accounts = localStorage.getItem("klir_accounts_v1"); } catch (e) {}
  try { data.directory = localStorage.getItem("klir_directory_v1"); } catch (e) {}
  try {
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && k.indexOf("klir_prospect_v2_") === 0) data.buckets[k] = localStorage.getItem(k);
    }
  } catch (e) {}
  return data;
}
async function rcExportFile(pass){
  var data = rcCollect();
  var n = Object.keys(data.buckets).length;
  if (!data.accounts && !n) throw new Error("Rien à sauvegarder sur cet appareil.");
  var salt = window.crypto.getRandomValues(new Uint8Array(16));
  var iv = window.crypto.getRandomValues(new Uint8Array(12));
  var key = await rcKey(pass, salt);
  var ct = await window.crypto.subtle.encrypt({ name: "AES-GCM", iv: iv }, key, new TextEncoder().encode(JSON.stringify(data)));
  var file = { app: RC_BTAG, v: 1, at: new Date().toISOString(), salt: rcB64e(salt), iv: rcB64e(iv), data: rcB64e(ct) };
  var d = new Date(), pad = function (x){ return String(x).padStart(2, "0"); };
  var name = "klir-secours-" + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + ".kns";
  var a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([JSON.stringify(file)], { type: "application/json" }));
  a.download = name;
  a.click();
  try { setTimeout(function(){ URL.revokeObjectURL(a.href); }, 5000); } catch (e) {}
  window.KlirStore.audit("secours.exported", n + " dossier(s)");
  return { ok: true, name: name, buckets: n };
}
async function rcImportFile(f, pass){
  var txt = await f.text();
  var file;
  try { file = JSON.parse(txt); } catch (e) { throw new Error("Fichier illisible (ce n'est pas un secours Klir)."); }
  if (!file || file.app !== RC_BTAG || !file.data) throw new Error("Fichier invalide (pas un secours Klir Prospect).");
  var key = await rcKey(pass, rcB64d(file.salt));
  var pt;
  try { pt = await window.crypto.subtle.decrypt({ name: "AES-GCM", iv: rcB64d(file.iv) }, key, rcB64d(file.data)); }
  catch (e) { throw new Error("Mot de passe incorrect ou fichier corrompu."); }
  var data = JSON.parse(new TextDecoder().decode(pt));
  var addedA = 0, keptA = 0, setB = 0, keptB = 0;
  var accs = {};
  try { accs = JSON.parse(localStorage.getItem("klir_accounts_v1")) || {}; } catch (e) { accs = {}; }
  var impAccs = {};
  try { impAccs = JSON.parse(data.accounts || "{}") || {}; } catch (e) {}
  Object.keys(impAccs).forEach(function (em){
    if (!accs[em]) { accs[em] = impAccs[em]; addedA++; }
    else keptA++;
  });
  try { localStorage.setItem("klir_accounts_v1", JSON.stringify(accs)); } catch (e) {}
  Object.keys(data.buckets || {}).forEach(function (k){
    var cur = null, imp = null;
    try { cur = JSON.parse(localStorage.getItem(k)); } catch (e) {}
    try { imp = JSON.parse(data.buckets[k]); } catch (e) {}
    if (!imp) return;
    var curN = cur ? ((cur.searches || []).length + (cur.prospects || []).length) : 0;
    var impN = ((imp.searches || []).length + (imp.prospects || []).length);
    var curT = (cur && cur._savedAt) || 0, impT = imp._savedAt || 0;
    if (!cur || impN > curN || (impN === curN && impT > curT)) {
      try { localStorage.setItem(k, data.buckets[k]); setB++; } catch (e) {}
    } else keptB++;
  });
  try {
    var dir = JSON.parse(localStorage.getItem("klir_directory_v1")) || {};
    var impDir = JSON.parse(data.directory || "{}") || {};
    Object.keys(impDir).forEach(function (em){
      if (!dir[em]) dir[em] = impDir[em];
      else dir[em].logins = Math.max(dir[em].logins || 0, impDir[em].logins || 0);
    });
    localStorage.setItem("klir_directory_v1", JSON.stringify(dir));
  } catch (e) {}
  try { if (window.root && window.root.kv) window.root.kv.prospect.set("secours_at", file.at || "").catch(function(){}); } catch (e) {}
  window.KlirStore.audit("secours.imported", addedA + " compte(s), " + setB + " dossier(s)");
  return { ok: true, at: file.at, addedA: addedA, keptA: keptA, setB: setB, keptB: keptB };
}
function rcCard(){
  var h = '<div class="card"><h3>💾 Secours & récupération (sans plateforme)</h3>';
  h += '<p><small>Vos comptes vivent dans ce navigateur. Créez un <b>fichier de secours chiffré</b> (.kns) : gardez-le (e-mail à vous-même, clé USB, cloud perso). Sur un nouvel appareil : <b>Restaurer</b> avec le fichier + votre mot de passe → tous vos comptes et dossiers reviennent. <b>Sans le mot de passe, le fichier est inutilisable.</b></small></p>';
  h += '<div class="grid4"><label>Mot de passe du secours<input id="rcP1" type="password" placeholder="Solide et mémorable"></label><label>Confirmer<input id="rcP2" type="password" placeholder="Répéter"></label></div>';
  h += '<div class="rowb"><button class="cta" id="rcExport">⬇ Créer mon fichier de secours</button></div>';
  h += '<div class="grid4"><label>Fichier de secours<input id="rcFile" type="file" accept=".kns,.json"></label><label>Mot de passe<input id="rcPass" type="password" placeholder="Mot de passe du fichier"></label></div>';
  h += '<div class="rowb"><button class="cta" id="rcImport">⬆ Restaurer depuis le fichier</button></div><p id="rcMsg"><small></small></p></div>';
  return h;
}
function rcBind(){
  function $(x){ return document.getElementById(x); }
  function msg(t, bad){ var m = $("rcMsg"); if (m) m.innerHTML = "<small style='color:" + (bad ? "#f87171" : "#34d399") + "'>" + t + "</small>"; }
  var ex = $("rcExport");
  if (ex) ex.onclick = async function(){
    var p1 = ($("rcP1") || {}).value || "", p2 = ($("rcP2") || {}).value || "";
    if (p1.length < 8) { msg("Mot de passe : 8 caractères minimum (c'est lui qui protège vos comptes).", true); return; }
    if (p1 !== p2) { msg("Les deux mots de passe ne correspondent pas.", true); return; }
    ex.textContent = "⏳ Chiffrement…"; ex.disabled = true;
    try {
      var r = await rcExportFile(p1);
      msg("Secours créé : <b>" + r.name + "</b> (" + r.buckets + " dossier(s)). Gardez-le + le mot de passe. ✅");
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    ex.disabled = false; ex.textContent = "⬇ Créer mon fichier de secours";
  };
  var im = $("rcImport");
  if (im) im.onclick = async function(){
    var f = ($("rcFile") || {}).files ? $("rcFile").files[0] : null;
    var p = ($("rcPass") || {}).value || "";
    if (!f) { msg("Choisissez d'abord votre fichier de secours (.kns).", true); return; }
    if (!p) { msg("Entrez le mot de passe du fichier.", true); return; }
    im.textContent = "⏳ Déchiffrement…"; im.disabled = true;
    try {
      var r2 = await rcImportFile(f, p);
      var d = r2.at ? r2.at.slice(0, 10) : "?";
      msg("Secours du " + d + " restauré : " + r2.addedA + " compte(s) ajouté(s), " + r2.setB + " dossier(s) mis à jour (" + r2.keptA + " compte(s) et " + r2.keptB + " dossier(s) déjà à jour conservés). Rechargement… ✅");
      setTimeout(function(){ location.reload(); }, 1200);
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    im.disabled = false; im.textContent = "⬆ Restaurer depuis le fichier";
  };
}
window.KlirSecours = { card: rcCard, bind: rcBind, exportFile: rcExportFile, importFile: rcImportFile };
