var NX_SESS_KEY = "klir_nuage_v1";
var NX_MAX_SEND = 300 * 1024;
var nxSock = null, nxConnecting = null, nxDead = false, nxPushT = null, nxLastSync = 0;
function nxSess(){ try { return JSON.parse(localStorage.getItem(NX_SESS_KEY)) || null; } catch (e) { return null; } }
function nxSetSess(s){ try { if (s) localStorage.setItem(NX_SESS_KEY, JSON.stringify(s)); else localStorage.removeItem(NX_SESS_KEY); } catch (e) {} }
function nxTimeout(p, ms){
  return Promise.race([p, new Promise(function (_, rej){ setTimeout(function(){ rej(new Error("timeout")); }, ms || 15000); })]);
}
async function nxConnect(){
  if (typeof window.root.createServerSocket !== "function") { nxDead = true; throw new Error("offline"); }
  if (nxDead) throw new Error("offline");
  if (nxSock) return nxSock;
  if (nxConnecting) return nxConnecting;
  nxConnecting = (async function (){
    var s = window.root.createServerSocket();
    try { s.binaryType = "arraybuffer"; } catch (e) {}
    if (s.closed) s.closed.then(function (ev){ if (ev && ev.code === 4403) nxDead = true; if (nxSock === s) nxSock = null; }, function (){});
    await nxTimeout(s.opened, 15000);
    nxSock = s;
    return s;
  })();
  try { return await nxConnecting; }
  finally { nxConnecting = null; }
}
async function nxRpc(method, arg){
  var s = await nxConnect();
  var raw = await nxTimeout(s.rpc[method](JSON.stringify(arg || {})), 20000);
  return JSON.parse(String(raw));
}
function nxPayload(){
  var KS = window.KlirStore;
  var st = null, dir = null;
  try {
    var cur = KS.S;
    var slim = { user: cur.user, org: cur.org, searches: cur.searches, prospects: cur.prospects, crm: cur.crm, campaigns: cur.campaigns, activities: (cur.activities || []).slice(0, 20), aiLog: (cur.aiLog || []).slice(-40), notifications: (cur.notifications || []).slice(0, 20), usage: cur.usage, plan: cur.plan, integrations: cur.integrations, optout: cur.optout, icp: cur.icp, radarCfg: cur.radarCfg, weights: cur.weights, credits: cur.credits, creditLog: (cur.creditLog || []).slice(0, 20), opps: cur.opps, watch: cur.watch, customLists: cur.customLists, deals: cur.deals, manualContacts: cur.manualContacts, webai: cur.webai, team: cur.team, radarStats: cur.radarStats, _savedAt: cur._savedAt };
    if (cur.projx) slim.projx = cur.projx;
    st = JSON.stringify(slim);
  } catch (e) { return { err: "Préparation impossible." }; }
  try { dir = localStorage.getItem("klir_directory_v1"); } catch (e) {}
  var p = JSON.stringify({ state: st, dir: dir, at: Date.now() });
  if (p.length > NX_MAX_SEND) return { err: "Données trop volumineuses pour le serveur (" + Math.round(p.length / 1024) + " Ko > 300 Ko). Allégez l'historique ou utilisez le fichier de secours." };
  return { payload: p };
}
async function nxPushNow(silent){
  var s = nxSess();
  if (!s || !s.token) return { err: "non-lié" };
  var pp = nxPayload();
  if (pp.err) return pp;
  var p = pp.payload, r;
  if (p.length <= 40000) {
    r = await nxRpc("push", { token: s.token, payload: p });
    if (!r.ok) {
      if ((r.err || "").indexOf("Session expirée") >= 0) nxSetSess(null);
      throw new Error(r.err || "Échec");
    }
  } else {
    var CH = 48000, n = Math.ceil(p.length / CH), i, c;
    var st = await nxRpc("push_start", { token: s.token, total: p.length, chunks: n });
    if (!st.ok) throw new Error(st.err || "Échec");
    for (i = 0; i < n; i++) {
      c = await nxRpc("push_chunk", { token: s.token, upid: st.upid, i: i, data: p.slice(i * CH, (i + 1) * CH) });
      if (!c.ok) throw new Error(c.err || "Échec");
    }
    var e = await nxRpc("push_end", { token: s.token, upid: st.upid });
    if (!e.ok) throw new Error(e.err || "Échec");
  }
  nxLastSync = Date.now();
  s.syncedAt = nxLastSync;
  nxSetSess(s);
  try { window.KlirStore.audit("nuage.push", "synchro serveur"); } catch (e) {}
  return { ok: true, at: nxLastSync };
}
function nxSchedulePush(){
  if (!nxSess()) return;
  if (nxPushT) return;
  nxPushT = setTimeout(function (){
    nxPushT = null;
    nxPushNow(true).catch(function (){});
  }, 8000);
}
function nxApplyRemote(email, pass, payload){
  var KS = window.KlirStore;
  var doc = JSON.parse(payload);
  var rst = JSON.parse(doc.state);
  try { KS.mergeHistory(rst, KS.S); } catch (e) {}
  var target = rst;
  target.user = { email: email };
  delete target.sharedFrom;
  KS.S = target;
  try {
    var dir = JSON.parse(localStorage.getItem("klir_directory_v1")) || {};
    var impDir = JSON.parse(doc.dir || "{}") || {};
    Object.keys(impDir).forEach(function (em){
      if (!dir[em]) dir[em] = impDir[em];
      else dir[em].logins = Math.max(dir[em].logins || 0, impDir[em].logins || 0);
    });
    localStorage.setItem("klir_directory_v1", JSON.stringify(dir));
  } catch (e) {}
  try {
    var accs = KS.getAccounts();
    if (!accs[email]) {
      var H = function (pw){ pw = String(pw || ""); var h1 = 0xdeadbeef, h2 = 0x41c6ce57; for (var i = 0; i < pw.length; i++){ var ch = pw.charCodeAt(i); h1 = Math.imul(h1 ^ ch, 2654435761); h2 = Math.imul(h2 ^ ch, 1597334677); } h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909); h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909); return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(36); };
      accs[email] = { email: email, hash: H(pass), at: new Date().toISOString() };
      KS.saveAccounts(accs);
    }
  } catch (e) {}
  KS.save();
  nxSchedulePush();
}
async function nxRpcBin(method, arg){
  var s = await nxConnect();
  var raw = await nxTimeout(s.rpc[method](JSON.stringify(arg || {})), 20000);
  if (typeof raw === "string") return raw;
  return raw;
}
async function nxPullNow(){
  var s = nxSess();
  if (!s || !s.token) throw new Error("non-lié");
  var m = await nxRpc("pull_meta", { token: s.token });
  if (!m.ok) {
    if ((m.err || "").indexOf("Session expirée") >= 0) nxSetSess(null);
    throw new Error(m.err || "Échec");
  }
  if (!m.len) return { empty: true };
  var CH = 65536, n = Math.ceil(m.len / CH), i, bufs = [], total = 0;
  for (i = 0; i < n; i++) {
    var off = i * CH, ln = Math.min(CH, m.len - off);
    var b = await nxRpcBin("pull_data", { token: s.token, off: off, len: ln });
    var u8 = b instanceof ArrayBuffer ? new Uint8Array(b) : new Uint8Array(0);
    if (u8.length !== ln) throw new Error("Tranche incomplète. Réessayez.");
    bufs.push(u8);
    total += u8.length;
  }
  var all = new Uint8Array(total), o = 0;
  for (i = 0; i < bufs.length; i++) { all.set(bufs[i], o); o += bufs[i].length; }
  var json = new TextDecoder().decode(all);
  nxApplyRemote(m.email, s.pass || "", json);
  nxLastSync = Date.now();
  s.syncedAt = nxLastSync;
  nxSetSess(s);
  return { ok: true, at: nxLastSync, updatedAt: m.updatedAt };
}
async function nxRegister(email, pass, name){
  var r = await nxRpc("register", { email: email, pass: pass, name: name });
  if (!r.ok) throw new Error(r.err || "Échec");
  nxSetSess({ email: r.email, token: r.token, pass: pass, syncedAt: 0 });
  await nxPushNow(true).catch(function (){});
  return r;
}
async function nxLogin(email, pass){
  var r = await nxRpc("login", { email: email, pass: pass });
  if (!r.ok) throw new Error(r.err || "Échec");
  nxSetSess({ email: r.email, token: r.token, pass: pass, syncedAt: 0 });
  var pulled = await nxPullNow().catch(function (e){ return { err: e.message }; });
  return { token: r.token, pulled: pulled };
}
function nxLogout(){ nxSetSess(null); nxLastSync = 0; }
function nxCard(){
  var s = nxSess();
  var h = '<div class="card"><h3>☁️ Compte Klir — vos données vous suivent</h3>';
  h += '<p><small>Un compte gratuit hébergé par Perchance, <b>sans rien à configurer</b>. Connectez-vous sur n\'importe quel ordinateur : vos recherches et prospects reviennent automatiquement. Hors Perchance (export statique), utilisez le fichier de secours ci-dessous.</small></p>';
  if (window.generatorIsUnsaved) h += '<p><small>🧪 Générateur non sauvegardé : le serveur réel s\'active quand vous cliquez <b>Sauvegarder</b>. En attendant, tout reste local.</small></p>';
  if (nxDead) {
    h += '<p><small>⚠️ Serveur inaccessible depuis cette page (export statique ou iframe externe). Le mode local + fichier de secours reste disponible.</small></p>';
  } else if (s && s.token) {
    var sync = s.syncedAt ? new Date(s.syncedAt).toLocaleString() : "jamais";
    h += '<p>✅ Connecté : <b>' + s.email + '</b><br><small>Dernière synchro : ' + sync + '</small></p>';
    h += '<div class="rowb"><button class="cta" id="nxSync">🔄 Synchroniser</button><button id="nxRecc">🔑 Mon code de récupération</button><button id="nxOut">Délier ce navigateur</button></div>';
    h += '<p id="nxMsg"><small></small></p><div id="nxRecBox"></div>';
  } else {
    h += '<div class="grid4"><label>E-mail<input id="nxEmail" placeholder="vous@entreprise.com"></label><label>Mot de passe (8+ caractères)<input id="nxPass" type="password"></label></div>';
    h += '<div class="rowb"><button class="cta" id="nxReg">Créer mon Compte Klir</button><button id="nxIn">Se connecter</button></div>';
    h += '<p id="nxMsg"><small></small></p><div id="nxRecBox"></div>';
    h += '<details><summary><small>Mot de passe oublié ? (code de récupération)</small></summary><div class="grid4"><label>E-mail<input id="nxREmail"></label><label>Code (XXXX-XXXX-XXXX-XXXX)<input id="nxRCode" placeholder="XXXX-XXXX-XXXX-XXXX"></label><label>Nouveau mot de passe<input id="nxRPass" type="password"></label></div><div class="rowb"><button id="nxReset">Réinitialiser</button></div></details>';
  }
  h += '</div>';
  return h;
}
function nxBind(){
  function $(x){ return document.getElementById(x); }
  function msg(t, bad){
    var m = $("nxMsg");
    if (m) m.innerHTML = "<small style='color:" + (bad ? "#f87171" : "#34d399") + "'>" + t + "</small>";
  }
  function busy(id, t){ var b = $(id); if (b){ b.disabled = true; b.dataset._t = b.textContent; b.textContent = t; } }
  function free(id){ var b = $(id); if (b){ b.disabled = false; if (b.dataset._t) b.textContent = b.dataset._t; } }
  function showRec(rec, fresh){
    var box = $("nxRecBox");
    if (!box) return;
    box.innerHTML = '<div class="card demoB"><h3>🔑 ' + (fresh ? 'Votre code de récupération — NOTEZ-LE' : 'Nouveau code de récupération — NOTEZ-LE') + '</h3><p><b style="font-size:18px">' + rec + '</b></p><p><small>Sans ce code, impossible de récupérer le compte si vous oubliez le mot de passe. Gardez-le avec votre fichier de secours.</small></p><div class="rowb"><button id="nxRecOk">C\'est noté</button></div></div>';
    var ok = $("nxRecOk");
    if (ok) ok.onclick = function (){ box.innerHTML = ""; };
  }
  var reg = $("nxReg");
  if (reg) reg.onclick = async function (){
    var em = ($("nxEmail") || {}).value || "", pw = ($("nxPass") || {}).value || "";
    if (!em || em.indexOf("@") < 0) { msg("Entrez un e-mail valide.", true); return; }
    if (pw.length < 8) { msg("Mot de passe : 8 caractères minimum.", true); return; }
    busy("nxReg", "⏳ Création…");
    try {
      var me = (window.KlirStore.S.user || {}).email || "";
      var r = await nxRegister(em, pw, me ? "" : em.split("@")[0]);
      msg("Compte créé ✅ Données de cet appareil envoyées au serveur.");
      showRec(r.recovery, true);
      setTimeout(function (){ try { render(); } catch (e) { location.reload(); } }, 800);
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    free("nxReg");
  };
  var lin = $("nxIn");
  if (lin) lin.onclick = async function (){
    var em = ($("nxEmail") || {}).value || "", pw = ($("nxPass") || {}).value || "";
    if (!em || !pw) { msg("E-mail + mot de passe requis.", true); return; }
    busy("nxIn", "⏳ Connexion…");
    try {
      var r2 = await nxLogin(em, pw);
      if (r2.pulled && r2.pulled.err) msg("Connecté ✅ mais synchro incomplète : " + r2.pulled.err, true);
      else msg("Connecté ✅ Données récupérées. Rechargement…");
      setTimeout(function (){ location.reload(); }, 1200);
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    free("nxIn");
  };
  var sy = $("nxSync");
  if (sy) sy.onclick = async function (){
    busy("nxSync", "⏳ Synchro…");
    try {
      await nxPushNow();
      var p = await nxPullNow().catch(function (e){ return { err: e.message }; });
      if (p && p.err) msg("Envoyé ✅, récupération incomplète : " + p.err, true);
      else msg("Synchronisé ✅ Rechargement…");
      setTimeout(function (){ location.reload(); }, 1000);
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    free("nxSync");
  };
  var rc = $("nxRecc");
  if (rc) rc.onclick = async function (){
    busy("nxRecc", "⏳ …");
    try {
      var s = nxSess();
      var r3 = await nxRpc("reccode", { token: s.token });
      if (!r3.ok) throw new Error(r3.err || "Échec");
      showRec(r3.recovery, false);
      msg("Nouveau code généré (l'ancien ne marche plus).");
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    free("nxRecc");
  };
  var out = $("nxOut");
  if (out) out.onclick = function (){
    nxLogout();
    msg("Navigateur délié. Vos données restent sur le serveur et sur cet appareil.");
    setTimeout(function (){ try { render(); } catch (e) { location.reload(); } }, 800);
  };
  var rs = $("nxReset");
  if (rs) rs.onclick = async function (){
    var em = ($("nxREmail") || {}).value || "", cd = ($("nxRCode") || {}).value || "", pw = ($("nxRPass") || {}).value || "";
    if (!em || !cd || pw.length < 8) { msg("Remplissez les 3 champs (nouveau mot de passe : 8+).", true); return; }
    busy("nxReset", "⏳ …");
    try {
      var r4 = await nxRpc("reset", { email: em, code: cd, nw: pw });
      if (!r4.ok) throw new Error(r4.err || "Échec");
      nxSetSess({ email: em, token: r4.token, pass: pw, syncedAt: 0 });
      msg("Mot de passe réinitialisé ✅ Rechargement…");
      showRec(r4.recovery, false);
      setTimeout(function (){ location.reload(); }, 2500);
    } catch (e) { msg("Échec : " + (e.message || e), true); }
    free("nxReset");
  };
}
try {
  if (window.KlirStore && window.KlirStore.save && !window.KlirStore.save._nx) {
    var nxOrigSave = window.KlirStore.save;
    var nxWrapped = function (){ nxOrigSave(); try { nxSchedulePush(); } catch (e) {} };
    nxWrapped._nx = true;
    window.KlirStore.save = nxWrapped;
  }
} catch (e) {}
setTimeout(function (){
  try {
    var s = nxSess();
    if (!s || !s.token || nxDead) return;
    nxPullNow().then(function (r){
      if (r && r.ok) {
        try {
          if (typeof render === "function" && (location.hash === "#/settings" || !location.hash)) render();
        } catch (e) {}
      }
    }).catch(function (){});
  } catch (e) {}
}, 2500);
window.KlirNuage = { card: nxCard, bind: nxBind, register: nxRegister, login: nxLogin, logout: nxLogout, pushNow: nxPushNow, pullNow: nxPullNow, session: nxSess, payload: nxPayload };
