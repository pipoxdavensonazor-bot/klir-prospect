var LS="klir_prospect_v1";
var DEF={user:null,org:null,searches:[],prospects:[],crm:[],campaigns:[],activities:[],aiLog:[],notifications:[],audit:[],usage:{searches:0,prospects:0,ai:0,exports:0},plan:"Free",integrations:{directory:{name:"Annuaire public (démo)",on:true,noKey:true},sirene:{name:"Sirene — données ouvertes FR (temps réel, sans clé)",on:false,noKey:true},registre:{name:"Registre entreprises (à configurer)",on:false,key:""},maps:{name:"Maps (à configurer)",on:false,key:""},web:{name:"Web public (à configurer)",on:false,key:""},gmail:{name:"Gmail (OAuth — à configurer)",on:false,key:""},outlook:{name:"Outlook (OAuth — à configurer)",on:false,key:""},hubspot:{name:"HubSpot (clé API — à configurer)",on:false,key:""},pipedrive:{name:"Pipedrive (clé API — à configurer)",on:false,key:""},outreach:{name:"Canal d'envoi campagnes (à configurer — aucun envoi sans ça)",on:false,key:""}},optout:[],demo:true,approvals:[],
icp:null,radarCfg:{signals:["Entreprise récente","Recrutement","Expansion","Nouveau site","Présence numérique active","Activité récente"],freq:"daily"},radarStats:null,weights:{industry:25,location:15,signals:15,size:10},credits:{balance:200},creditLog:[],opps:[],watch:[],apiKey:null,customLists:[]};
var LIMITS={Free:{searches:10,prospects:500,ai:100,exports:20},Pro:{searches:100,prospects:10000,ai:2000,exports:500},Business:{searches:999999,prospects:9999999,ai:999999,exports:999999}};
var _S;
try{_S=Object.assign(structuredClone(DEF),JSON.parse(localStorage.getItem(LS))||{});}catch{_S=structuredClone(DEF);}
_S.usage=Object.assign({searches:0,prospects:0,ai:0,exports:0},_S.usage||{});
_S.integrations=Object.assign(structuredClone(DEF.integrations),_S.integrations||{});
for(const k of ["notifications","audit","optout","approvals","creditLog","opps","watch","customLists","deals","manualContacts"]) if(!Array.isArray(_S[k])) _S[k]=[];
if(!_S.weights)_S.weights={industry:25,location:15,signals:15,size:10};
if(!_S.credits)_S.credits={balance:200};
if(!_S.plan)_S.plan="Free"; if(_S.demo===undefined)_S.demo=true;
function save(){localStorage.setItem(LS,JSON.stringify(_S));}
function addActivity(t){_S.activities.unshift({t,at:new Date().toLocaleString()});_S.activities=_S.activities.slice(0,30);save();}
function notify(t){_S.notifications.unshift({t,at:new Date().toLocaleString(),read:false});_S.notifications=_S.notifications.slice(0,30);save();}
function audit(action,entity){_S.audit.unshift({by:_S.user?_S.user.email:"?",org:_S.org?_S.org.name:"?",action,entity:entity||"",at:new Date().toLocaleString()});_S.audit=_S.audit.slice(0,200);save();}
function uid(p){return (p||"id")+"_"+Math.random().toString(36).slice(2,8);}
async function aiText(prompt, fallback){ try{ if(window.root&&window.root.generateText){ const r = await Promise.race([window.root.generateText(prompt), new Promise((_,rej)=>setTimeout(()=>rej(new Error("ai-timeout")), 25000))]); if(typeof r==="string") return r; if(r&&r.text) return r.text; return String(r); } }catch(e){} return fallback; }

window.KlirStore={get S(){return _S;},save,addActivity,notify,audit,uid,aiText,LS,LIMITS};
