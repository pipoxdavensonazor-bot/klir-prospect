KLIR PROSPECT — PROD V1 (klirprospect.klirline.ca)
Deploys tel quel (Cloudflare Pages/Workers + wrangler.toml, ou GitHub Pages/Netlify/Vercel).
Donnees locales (localStorage). Connecteur live Sirene pour recherches France : Reglages → Integrations → Activer.