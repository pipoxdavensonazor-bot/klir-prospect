KLIR PROSPECT — site autonome
============================

Lancez : ouvrez index.html dans un navigateur, ou hébergez le dossier
(GitHub Pages, Netlify, Vercel : glissez-déposez le dossier).

Notes :
- Données stockées en local (localStorage). Aucun serveur requis.
- IA : sans clé, les messages utilisent le mode local. Pour brancher un
  vrai LLM, définissez window.root = { generateText: async (p) => "..." }
  avant src/store.js (voir CONFIG-AI dans index.html).
- Contenu de démonstration : basculez DEMO/LIVE dans Réglages.
